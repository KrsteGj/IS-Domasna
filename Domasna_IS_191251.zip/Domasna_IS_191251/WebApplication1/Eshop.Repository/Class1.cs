﻿using System;

namespace Eshop.Repository
{
    public class Class1
    {
    }
}
