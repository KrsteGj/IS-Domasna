﻿using Eshop.Domain.DomainModels;
using Eshop.Service.Implementation;
using Eshop.Service.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        public readonly IOrderService _ordereService;
        public AdminController(IOrderService service)
        {
            _ordereService = service;
        }
        [HttpGet("[action]")]
        public List<Order> GetAllActiveOrders()
        {
            return _ordereService.getAllOrders();
        }

        [HttpPost("[action]")]
        public Order GetOrderDetails(BaseEntity model)
        {
            return _ordereService.getOrderDetails(model);
        }
    }
}
