﻿namespace WebApplication1.Controllers
{
    internal class model
    {
    }
}