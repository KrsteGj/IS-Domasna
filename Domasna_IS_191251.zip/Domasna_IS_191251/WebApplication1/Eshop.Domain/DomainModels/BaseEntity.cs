﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eshop.Domain.DomainModels
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}
