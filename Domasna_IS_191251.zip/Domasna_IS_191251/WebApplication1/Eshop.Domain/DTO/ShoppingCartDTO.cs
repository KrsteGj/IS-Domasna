﻿using Eshop.Domain.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eshop.Domain.DTO
{
    public class ShoppingCartDTO
    {
        public List<ProductsInShoppingCart> ProductsInShoppingCart { get; set; }
        public float TotalPrice { get; set; }
    }
}
