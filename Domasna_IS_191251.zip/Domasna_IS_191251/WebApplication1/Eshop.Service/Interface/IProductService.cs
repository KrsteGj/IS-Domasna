﻿using Eshop.Domain.DomainModels;
using Eshop.Domain.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace Eshop.Service.Interface
{
    public interface IProductService
    {
        List<Product> GetAllProducts();
        Product GetDetailsForProduct(int id);
        void CreateNewProduct(Product p);
        void UpdateExistingProduct(Product p);
        ShoppingCartDTO GetShoppingCartInfo(int id);
        void DeleteProduct(int id);
        bool AddToShoppingCart(AddToShoppingCartDTO item, string userID);
    }
}
