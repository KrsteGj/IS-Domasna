﻿using System;

namespace Eshop.Service
{
    public class Class1
    {
    }
}
