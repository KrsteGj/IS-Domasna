﻿using Eshop.Domain.DomainModels;
using Eshop.Domain.DTO;
using Eshop.Repository.Interface;
using Eshop.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Eshop.Service.Implementation
{
    public class ProductService : IProductService
    {
        public readonly IRepository<Product> _productRepository;
        public readonly IRepository<ProductsInShoppingCart> _productInShoppingCartRepository;
        public readonly IUserRepository _userRepository;

        public ProductService(IRepository<Product> productRepository,IUserRepository userRepository, IRepository<ProductsInShoppingCart> productInShoppingCartRepository)
        {
            _productRepository = productRepository;
            _userRepository = userRepository;
            _productInShoppingCartRepository = productInShoppingCartRepository;
        }
        public bool AddToShoppingCart(AddToShoppingCartDTO item, string userID)
        {
            var user = _userRepository.Get(userID); ;
            var userShoppingCard = user.UserShoppingCart;
            if(userShoppingCard != null)
            {
                var product = this.GetDetailsForProduct(item.ProductId);

                if(product != null)
                {
                    ProductsInShoppingCart itemToAdd = new ProductsInShoppingCart
                    {
                        Product = product,
                        ProductId = product.Id,
                        ShoppingCart = userShoppingCard,
                        CartId = userShoppingCard.Id,
                        Quantity = item.Quantity
                    };

                    _productInShoppingCartRepository.Insert(itemToAdd);
                    return true;
                }
                return false;
            }
            return false;
        }

        public void CreateNewProduct(Product p)
        {
            this._productRepository.Insert(p);
        }

        public void DeleteProduct(int id)
        {
            var product = _productRepository.Get(id);
            this._productRepository.Delete(product);
        }

        public List<Product> GetAllProducts()
        {
            return _productRepository.GetAll().ToList();
        }

        public Product GetDetailsForProduct(int id)
        {
            return _productRepository.Get(id);
        }

        public ShoppingCartDTO GetShoppingCartInfo(int id)
        {
            throw new NotImplementedException();
        }

        public void UpdateExistingProduct(Product p)
        {
            _productRepository.Update(p);
        }
    }
}
