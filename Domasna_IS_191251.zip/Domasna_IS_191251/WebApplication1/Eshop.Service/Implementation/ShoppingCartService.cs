﻿using Eshop.Domain.DomainModels;
using Eshop.Domain.DTO;
using Eshop.Repository.Interface;
using Eshop.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Eshop.Service.Implementation
{
    public class ShoppingCartService : IShoppingCartService
    {
        public readonly IUserRepository _userRepository;
        public readonly IRepository<ProductInOrder> _productInOrdersRepository;
        public readonly IRepository<ShoppingCart> _shoppingCartRepository;
        private readonly IRepository<Order> _orderRepository;
        public ShoppingCartService(IUserRepository userRepository, IRepository<ProductInOrder> productInOrdersRepository, IRepository<ShoppingCart> shoppingCartRepository, IRepository<Order> orderRepository)
        {
            _userRepository = userRepository;
            _productInOrdersRepository = productInOrdersRepository;
            _shoppingCartRepository = shoppingCartRepository;
            _orderRepository = orderRepository;
    }
        public bool DeleteProductFromShoppingCart(string userId, int productId)
        {
            if(!string.IsNullOrEmpty(userId) && productId != null)
            {
                var loggInUser = _userRepository.Get(userId);
                var userShoppingCart = loggInUser.UserShoppingCart;
                var itemToDelete = userShoppingCart.ProductsInShoppingCarts.Where(z => z.ProductId == productId).FirstOrDefault();
                userShoppingCart.ProductsInShoppingCarts.Remove(itemToDelete);
                _shoppingCartRepository.Update(userShoppingCart);
                return true;
            }
            else
            {
                return false;
            }
        }

        public ShoppingCartDTO getShoppingCartInfo(string userId)
        {
           
            var user = _userRepository.Get(userId);

            var userShoppingcart = user.UserShoppingCart;

            var productList = userShoppingcart.ProductsInShoppingCarts.Select(z => new
            {
                Quantity = z.Quantity,
                ProductPrice = z.Product.ProductPrice
            });

            float totalPrice = 0;
            foreach (var item in productList)
            {
                totalPrice += item.ProductPrice * item.Quantity;
            }

            ShoppingCartDTO model = new ShoppingCartDTO
            {
                TotalPrice = totalPrice,
                ProductsInShoppingCart = userShoppingcart.ProductsInShoppingCarts.ToList()
            };

            return model;
        }

        public bool OrderNow(string userId)
        {
            
            var user = _userRepository.Get(userId);

            var userShoppingCart = user.UserShoppingCart;

            Order newOrder = new Order
            {
                UserId = user.Id,
                OrderedBy = user
            };
            _orderRepository.Insert(newOrder);

            List<ProductInOrder> productInOrder = userShoppingCart.ProductsInShoppingCarts.Select(z => new ProductInOrder
            {
                Product = z.Product,
                ProductId = z.ProductId,
                Order = newOrder,
                OrderId = newOrder.Id
            }).ToList();

            foreach (var item in productInOrder)
            {
                _productInOrdersRepository.Insert(item);
            }

            user.UserShoppingCart.ProductsInShoppingCarts.Clear();
            _userRepository.Update(user);
            return true;
        }
    }
}
