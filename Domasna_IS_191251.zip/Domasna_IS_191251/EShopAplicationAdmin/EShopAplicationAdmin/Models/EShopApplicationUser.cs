﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EShopAplicationAdmin.Models
{
    public class EShopApplicationUser
    {
        public string Email { get; set; }
        public  string NormalizedEmail { get; set; }
        public int Username { get; set; }
        public string NormalizedUsername { get; set; }
        
    }
}
